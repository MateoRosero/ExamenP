import javax.swing.*;

public class Interfaz {
    private JTabbedPane tabbedPane1;
    private JPanel panel1;
    private JTextField textFieldNombre;
    private JButton agregarALaColaButton;
    private JTextField textField1;
    private JButton buscarButton;
    private JButton buscarMayorPrioridadButton;
    private JTextArea textArea1;
    private JCheckBox checkBox1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JTextField textField5;
    private JTextField textField6;
    private JTextField textField7;
    private JButton ingresarDatos1Button;
    private JButton ingresarDatos2Button;
    private JButton ingresarDatos3Button;
    private JButton ingresarDatos4Button;
    private JButton ingresarDatos5Button;
    private JButton ingresarDatos6Button;
    private JButton siguienteEnLaColaButton;
    private JButton activarEsperaButton;
    private JButton eliminarParticipantesDeLaButton;
    private JButton eliminarParticipantesButton;
    private JButton restaurarUltimoEliminadoButton;
    private JButton restaurarParticipantesButton;


}

